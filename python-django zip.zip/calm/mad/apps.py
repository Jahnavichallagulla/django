from django.apps import AppConfig


class GetConfig(AppConfig):
    name = 'get'
