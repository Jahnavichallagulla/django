from django.db import models

# Create your models here.
class travello(models.Model):
    name=models.CharField(max_length=200)
    desc=models.TextField()
    img=models.ImageField(upload_to='pictures')
class contact(models.Model):
    name=models.CharField(max_length=200)
    email=models.EmailField()
    comment=models.TextField()
class newbook(models.Model):
    name=models.CharField(max_length=200)
    email=models.EmailField()
    address=models.TextField()
    city=models.CharField(max_length=200)
class rate(models.Model):
    minprice=models.IntegerField()
    maxprice=models.IntegerField()
    city=models.CharField(max_length=300)
