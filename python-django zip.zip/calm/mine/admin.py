from django.contrib import admin
from .models import travello,contact,rate,newbook
# Register your models here.
admin.site.register(travello)
admin.site.register(contact)
admin.site.register(rate)
admin.site.register(newbook)