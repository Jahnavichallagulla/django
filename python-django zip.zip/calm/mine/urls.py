from django.urls import path
from . import views
urlpatterns = [
    path('',views.home,name='home'),
    path('search',views.search,name='search'),
    path('about',views.about,name='about'),
    path('details',views.details,name='details'),
    path('submit',views.submit,name='submit'),
    path('book',views.book,name='book'),
    path('do',views.do,name='do'),
    path('req',views.req,name='req')
] 