from django.shortcuts import render,redirect
from .models import travello,contact,rate

def home(request):
    dests=travello.objects.all()
    return render(request,'index.html',{'dests':dests})
def about(request):
    return render(request,'about.html')
def details(request):
    n=request.POST['name']
    e=request.POST['email']
    c=request.POST['comment']
    userc=contact.objects.create(name=n,email=e,comment=c)
    userc.save()
    print("user created")
    return redirect('submit')
def submit(request):
    return render(request,'submit.html')
def search(request):
    n=int(request.POST['min'])
    e=int(request.POST['max'])
    rts=rate.objects.all()
    for r in rts:

        if n>=r.minprice and e<=r.maxprice:
            return render(request,'result.html',{'city':r.city})
        else:
            return render(request,'index.html')

def book(request):
    return render(request,'book.html')
def do(request):
    n=request.POST['name']
    e=request.POST['email']
    c=request.POST['address']
    s=request.POST['city']
    userb=newbook.objects.create(name='n',email='e',address='c',city='s')
    userb.save()
    return redirect('req')
def req(request):
    return render(request,'req.html')
